# EDLC Machine Learning and Inverse Design

## Study
An Interpretable Machine Learning Framework for Prediction and
Inverse Design of High-Performance Electric Double-Layer Capacitors

## Dataset
- Experimental records: 556
- Total dataset columns: 78
- Input features: 77
- Target variable: Capacitance (F/g)

## Input feature composition
- Continuous physicochemical descriptors: 13
- Material_1 one-hot features: 37
- Material_2 one-hot features: 6
- Electrolyte one-hot features: 21

Therefore:

13 continuous + 64 one-hot = 77 input features

Capacitance is the target variable and is not used as an input feature.

## Continuous descriptors
1. Voltage
2. SSA
3. PoreVolume
4. PoreSize
5. MicroPoreVolume
6. MicroSSA
7. ID_IG
8. N
9. O
10. B
11. S
12. F
13. P

## Target
Specific capacitance (F/g)

- Minimum: 1.9 F/g
- Maximum: 587.0 F/g
- Mean: 188.8076 F/g
- Median: 177.0 F/g

## Final XGBoost model

Independent test set:
- Training samples: 444
- Independent test samples: 112
- Random state: 42

Performance:
- MAE: 18.0135 F/g
- RMSE: 26.8198 F/g
- R2: 0.9294

Five-fold cross-validation:
- MAE: 26.0862 ± 4.2518 F/g
- RMSE: 39.7176 ± 7.1703 F/g
- R2: 0.8504 ± 0.0454

## Model interpretation
The final XGBoost model was interpreted using:
- XGBoost feature importance
- Permutation feature importance
- SHAP analysis

Important descriptors included sulfur, oxygen, nitrogen,
ID/IG, SSA, voltage, boron, and pore-related descriptors.

## Inverse design

A total of 42,000 computational candidate configurations
were screened using the trained XGBoost model.

- Total candidates: 42,000
- Candidates predicted >= 400 F/g: 97
- Highest broad-screening prediction: 519.93 F/g

Local Differential Evolution refinement was then performed
for the most promising categorical combinations.

## AI-proposed candidate

Material_1: N-doped carbon
Material_2: CNT
Electrolyte: BMIMBF4

Predicted specific capacitance:

575.37 F/g

This value is a computational prediction and has not been
experimentally validated.

The maximum experimentally measured capacitance in the dataset
is 587.0 F/g.

## Applicability domain

For the prioritized candidate:
- Features outside individual training ranges: 0
- Nearest standardized training distance: 5.7152
- Mean distance to 5 nearest samples: 5.7790
- Mean distance to 10 nearest samples: 5.9032

The candidate is therefore within the individual descriptor
ranges but was identified as a potential extrapolation in the
multivariate feature space.

## Package contents

01_AI_Ready_Dataset_556x78.xlsx
02_FINAL_XGBOOST_SUPERCAPACITOR.pkl
03_FINAL_XGBOOST_FEATURES.json
04_INVERSE_DESIGN_FINAL_VALIDATION.xlsx
05_README.md

## Reproducibility

The same 77-feature representation and feature ordering were
maintained throughout model training, testing, interpretation,
inverse-design screening, optimization, and applicability-domain
assessment.

The final XGBoost model was saved as a fixed model artifact.

Inverse-design predictions should be experimentally validated
before being interpreted as confirmed material properties.

## Version

v1.0
